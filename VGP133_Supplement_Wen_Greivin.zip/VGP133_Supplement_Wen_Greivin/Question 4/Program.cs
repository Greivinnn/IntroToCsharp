﻿// See https://aka.ms/new-console-template for more information
using Question_4;

Game game = new Game();
game.Start();
