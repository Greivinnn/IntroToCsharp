﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    public class Card
    {
        public string _suit;
        public int _value;

        public Card(string suit, int value)
        {
            _suit = suit;
            _value = value;
        }
    }
}
