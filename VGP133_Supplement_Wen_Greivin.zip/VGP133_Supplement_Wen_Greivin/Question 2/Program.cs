﻿// See https://aka.ms/new-console-template for more information
using Question_2;

Game wordGame = new Game();
wordGame.Start();
